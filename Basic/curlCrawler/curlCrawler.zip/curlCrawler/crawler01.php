<?php
$curl=curl_init('http://www.baidu.com');
curl_exec($curl);
curl_close($curl);
?>